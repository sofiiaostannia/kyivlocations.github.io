# Countdown Timer

A Pen created on CodePen.

Original URL: [https://codepen.io/AllThingsSmitty/pen/JJavZN](https://codepen.io/AllThingsSmitty/pen/JJavZN).

A how-to for a countdown clock.